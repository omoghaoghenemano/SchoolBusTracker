package com.example.gpstracking.Model;

public class UserAdapter {
}
