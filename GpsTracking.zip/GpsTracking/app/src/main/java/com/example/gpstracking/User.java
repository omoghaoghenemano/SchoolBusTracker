package com.example.gpstracking;

public class User {
    public String Username, Name, Email;
            public User(){

            }
            public User(String Username, String Name, String Email){
                this.Username = Username;
                this.Name = Name;
                this.Email = Email;


            }
}
