package com.example.gpstracking.Model.Routes;

public class Route {



    public String Name;
   public  int imageId;
   public  Double Lat, Lng;

    public Route(String name, int imageId, Double lat, Double lng) {
        Name = name;
        this.imageId = imageId;
        Lat = lat;
        Lng = lng;
    }
}
