package com.example.gpstracking;public class BusAdapter {
}
